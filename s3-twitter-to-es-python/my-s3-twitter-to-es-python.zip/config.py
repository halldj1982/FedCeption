'''
Created on Oct 12, 2015

@author: mentzera

'''

es_host = 'search-fedception-es-ynqxrgpew2wwkvou7pfrdkieki.us-east-1.es.amazonaws.com' #without the https - for example: search-es-twitter-demo-xxxxxxxxxxxxxxxxxxx.us-east-1-.es.amazonaws.com
es_port = 80
es_bulk_chunk_size = 1000  #number of documents to index in a single bulk operation

