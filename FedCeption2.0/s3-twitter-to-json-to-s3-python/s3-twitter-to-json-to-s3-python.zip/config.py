'''
Created on Oct 12, 2015

@author: mentzera

'''

es_host = 'search-es-twitter-demo-u3rqpsw352ypcrbvy6eivuc2bm.us-east-1.es.amazonaws.com' #without the https - for example: search-es-twitter-demo-xxxxxxxxxxxxxxxxxxx.us-east-1-.es.amazonaws.com
es_port = 80
es_bulk_chunk_size = 1000  #number of documents to index in a single bulk operation

